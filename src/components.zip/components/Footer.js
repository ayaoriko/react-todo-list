export default function Footer() {
  return (
    <footer id="Footer" className="footer">
      <div className="footer-inner">
        <p className="footer-text">© 2025 ayaoriko</p>
      </div>
    </footer>
  );
}
